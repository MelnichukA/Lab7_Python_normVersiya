from django.apps import AppConfig


class AtmomoduleConfig(AppConfig):
    name = 'atmomodule'
